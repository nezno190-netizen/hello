# GitHub Pages Video

1. Upload `index.html` dan video kamu ke repository yang sama.
2. Rename video menjadi `video.mp4`.
3. Di `index.html`, ganti `https://example.com` dengan URL tujuan.
4. Aktifkan GitHub Pages dari Settings → Pages → Deploy from a branch → main → / (root).
